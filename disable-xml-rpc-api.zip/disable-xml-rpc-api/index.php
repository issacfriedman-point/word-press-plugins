<?php // silence is golden

