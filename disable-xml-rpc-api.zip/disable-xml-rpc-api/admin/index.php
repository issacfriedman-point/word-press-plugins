<?php
	// Silence is golden.