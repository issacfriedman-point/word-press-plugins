<?php
defined('ABSPATH') or die("you do not have access to this page!");

$this->pages['all'] = array(
     'terms-conditions' => array(
         'title' => __("Terms and Conditions", 'complianz-terms-conditions'),
         'public' => true,
         'document_elements' => '',
     ),
);
