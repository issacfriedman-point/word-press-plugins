<div class="cmplz-wizard-menu">
    <div class="cmplz-wizard-title"><h1 class="h4"><?php _e( "The Wizard", 'complianz-terms-conditions' ) ?></h1></div>
    <div class="cmplz-wizard-progress-bar">
        <div class="cmplz-wizard-progress-bar-value" style="width: {percentage-complete}%"></div>
    </div>
    {title}
    <div class="cmplz-wizard-menu-menus">
        {steps}
    </div>
</div>
