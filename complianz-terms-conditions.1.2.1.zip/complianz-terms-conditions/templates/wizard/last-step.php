<div class="cmplz-trick">
    <a href="https://complianz.io/translating-terms-conditions/" target="_blank">
        <div class="cmplz-bullet" style=""></div>
        <div class="cmplz-tips-tricks-content"><?php printf(__("Translating %s", "complianz-terms-conditions"), __("Terms & Conditions", "complianz-terms-conditions"))?></div>
    </a>
</div>

<div class="cmplz-trick">
    <a href="https://complianz.io/styling-terms-conditions/" target="_blank">
        <div class="cmplz-bullet"></div>
        <div class="cmplz-tips-tricks-content"><?php printf(__("Styling %s", "complianz-terms-conditions"), __("Terms & Conditions", "complianz-terms-conditions"))?></div>
    </a>
</div>

<div class="cmplz-trick">
    <a href="https://complianz.io/editing-terms-conditions/" target="_blank">
        <div class="cmplz-bullet" style=""></div>
        <div class="cmplz-tips-tricks-content"><?php printf(__("Editing %s", "complianz-terms-conditions"), __("Terms & Conditions", "complianz-terms-conditions"))?></div>
    </a>
</div>

<div class="cmplz-trick">
    <a href="https://complianz.io/woocommerce-terms-conditions/" target="_blank">
        <div class="cmplz-bullet"></div>
        <div class="cmplz-tips-tricks-content"><?php _e("Adding to WooCommerce", "complianz-terms-conditions")?></div>
    </a>
</div>
