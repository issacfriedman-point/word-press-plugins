<?php

namespace Google\Site_Kit_Dependencies\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \Google\Site_Kit_Dependencies\GuzzleHttp\Exception\GuzzleException
{
}
