<?php

namespace Google\Site_Kit_Dependencies\Psr\Cache;

/**
 * Exception interface for all exceptions thrown by an Implementing Library.
 */
interface CacheException
{
}
